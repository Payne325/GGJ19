import sys

class Drawable:
  def __init__(self):
    pass

  def Draw(self, z_dist, engine):
    print("This is the 'Drawable' abstract class you levitating tea spoon!")
    sys.exit()
